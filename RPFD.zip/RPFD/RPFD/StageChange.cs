﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.ComponentModel;
using System.IO;
using Newtonsoft.Json;

namespace RPFD
{
    public enum Status
    {
        NotYetStarted,
        InProgress,
        Completed
    }  
    public class StageChange : CodeActivity
    {
       

        //[Category("Input")]
        //[Description("RobotName which will display in the End HTML Flow Diagram. Only string values are supported")]
        //[DefaultValue("UiPath Robot")]
        //public InArgument<string> RobotName { get; set; }

        //[Category("Input")]
        //[Description(@"RPFD HTML File Path , you can use shared folder also, Ex:- C:\UiPath\RobotProcessFlow\. Only string values are supported")]
        //public InArgument<string> HTMLFilePath { get; set; }
        
        [Category("Input")]
        [Description(@"The Object to be display in to HTML File . Only Object of type IDictionary<string, string> values are supported")]
        [RequiredArgument]
        public InArgument<IDictionary<string, string>> ProcessSteps { get; set; }

        [Category("Input")]
        [Description(@"Current Stage as String it should be available in ProcessSteps Object. Only string values are supported")]
        public InArgument<string> CurrentStageString { get; set; }

        [Category("Input")]
        [Description(@"Current Stage as Index it should be from ProcessSteps Object, Starts With 1. Only int values are supported")]
        public InArgument<int> CurrentStageIndex { get; set; }

        [Category("Input")]
        [Description(@"The Text to be show as tooltip for the Current Stage. Only string values are supported")]
        public InArgument<string> toolTip { get; set; }

        //[Category("Input")]
        //[Description(@"HTML Page Auto Refresh Seconds, This Number Minumum 5 . Only int values are supported")]
        //[DefaultValue(8)]
        //public InArgument<int> PageRefreshSec { get; set; }


        [Category("Input")]
   
        [Description(@"Select the Current Status of the Stage in the Process, InProgress,Completed,NotYetStarted")]
        public  Status CurrentStatus { get; set; }

        [Category("Output")]
        [Description(@"If Any Error , this is the output, it is Exception string value ")]
        public OutArgument<string> ErrorStatus { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            Console.WriteLine("InSide Execute");
            #region TotalProces
            try
            {
                var CurrentPath = Directory.GetCurrentDirectory();
               
           

                var _Status = (Status)CurrentStatus;
                string DefaultNodeValues = "{name:'No Process Found',tooltip:'Status:NotYetStarted',status:'NotYetStarted',img:'code'}";
                string defaultHTMLDiv = @"<div ng-app="""" ng-init=""names=[" + DefaultNodeValues.ToString() + @"]"">";
                var _HTMLFilePath = ""; // HTMLFilePath.Get(context);

               // _HTMLFilePath = (_HTMLFilePath.ToString().Trim().EndsWith("\\")) ? _HTMLFilePath : _HTMLFilePath + "\\";
                var _ProcessSteps = ProcessSteps.Get(context);


                var _RobotName = new DirectoryInfo(CurrentPath).Name;  // RobotName.Get(context);
                var _CurrentStageString = CurrentStageString.Get(context);
                var _CurrentStageIndex = CurrentStageIndex.Get(context);
                var _toolTip = toolTip.Get(context);
                //            Status _Status = _Status.Completed;
                var _PageRefreshSec = 3;  // PageRefreshSec.Get(context);

                //if (Convert.ToInt32(_PageRefreshSec) < 5)
                //    _PageRefreshSec = 5;
               // Console.WriteLine("_CurrentStageIndex:" + _CurrentStageIndex + ", _PageRefreshSec:" + _PageRefreshSec);

                if (_CurrentStageIndex == 0)
                    _CurrentStageIndex = -1;
                
                    _CurrentStageIndex = _CurrentStageIndex - 1 ;

                if (!System.IO.File.Exists(_HTMLFilePath + @"RPFD.html"))
                    System.IO.File.WriteAllText(_HTMLFilePath + @"RPFD.html", getDefaultHTML().Replace("@PageRefreshSec", _PageRefreshSec.ToString()));


                string allFile = "";
                //get Div List []
                string DIVfound = "";
                using (StreamReader file = new StreamReader(_HTMLFilePath + @"RPFD.html"))
                {
                    allFile = file.ReadToEnd();
                    int start = allFile.IndexOf("[");
                    int last = allFile.IndexOf("]");
                    int offset = start;
                    int length = (last - start) + 1;
                    DIVfound = allFile.Substring(offset, length);
                }
                if (DIVfound.Contains("No Process Found"))
                {
                    string allNodes = "";
                    //Prepare the FirstStageProcess
                    foreach (KeyValuePair<string, string> stage in _ProcessSteps)
                    {
                        string CurStage = "";
                        // do something with entry.Value or entry.Key
                        if (_CurrentStageString == stage.Key.ToString() || _CurrentStageIndex == Array.IndexOf(_ProcessSteps.Keys.ToArray(), stage.Key))
                            CurStage = "{name:'" + stage.Key + "',tooltip:'Status:" + _Status.ToString() + " \n Message:" + _toolTip + "',status:'" + _Status.ToString() + "',img:'" + stage.Value + "'}";
                        else
                            CurStage = "{name:'" + stage.Key + "',tooltip:'Status:NotYetStarted\n Message:Empty',status:'NotYetStarted',img:'" + stage.Value + "'}";
                        allNodes += "," + CurStage;
                    }
                    allNodes = allNodes.Substring(1, (allNodes.Length - 1));
                    //if (!System.IO.File.Exists(_HTMLFilePath + @"RPFD.html"))

                    System.IO.File.WriteAllText(_HTMLFilePath + @"RPFD.html", getDefaultHTML().Replace("@PageRefreshSec", _PageRefreshSec.ToString()).Replace(defaultHTMLDiv, @"<div ng-app="""" ng-init=""names=[" + allNodes.ToString() + @"]"">").Replace("@RobotName", _RobotName));

                }
                else {
                    var list = JsonConvert.DeserializeObject<List<JSonStage>>(DIVfound);
                    foreach (var _stage in list)
                    {
                        if (_stage.name == _CurrentStageString)
                        {
                            _stage.status = _Status.ToString();
                            _stage.tooltip = "Status:" + _Status.ToString() + " \n Message:" + _toolTip;
                            _stage.img = _ProcessSteps.First(x => x.Key == _stage.name).Value.ToString();
                            Console.WriteLine("------->"+_ProcessSteps.First(x => x.Key == _stage.name).Value.ToString());
                        }
                        if (Convert.ToInt32(_CurrentStageIndex) >= 0)
                            if (list.ElementAt(Convert.ToInt32(_CurrentStageIndex)).name == _stage.name)
                            {
                                _stage.status = _Status.ToString();
                                _stage.tooltip = "Status:" + _Status.ToString() + " \n Message:" + _toolTip;
                                _stage.img = _ProcessSteps.First(x => x.Key == _stage.name).Value.ToString();
                                Console.WriteLine("------->" + _ProcessSteps.First(x => x.Key == _stage.name).Value.ToString());
                            }
                    }


                    string finalStr = JsonConvert.SerializeObject(list);
                    allFile = allFile.Replace(DIVfound, (finalStr.Replace("\"name\"", "name").Replace("\"img\"", "img").Replace("\"tooltip\"", "tooltip").Replace("\"status\"", "status")).Replace("\"", "'"));
                    System.IO.File.WriteAllText(_HTMLFilePath + @"RPFD.html", allFile.Replace("@PageRefreshSec", _PageRefreshSec.ToString()).Replace("@RobotName", _RobotName));
                }
            }
            catch (Exception ex)
            {
                ErrorStatus.Set(context, ex.Message.ToString());
            }
            #endregion
        }
        public  string getDefaultHTML()
        {
            return @"<!DOCTYPE html>
<html>
<head>
<meta name = ""viewport"" content = ""width=device-width, initial-scale=1"">
   <link rel = ""stylesheet"" href = ""https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"">
      
        <meta http-equiv = ""refresh"" content = ""@PageRefreshSec"" />
           <style>


#Completed {
    border-radius: 15px;
            background: #73AD21;
    align-content: center;
            padding: 20px;
            color: white;
            width: auto;
            height: auto;
            font-family:Tahoma;
        }
.right {
    transform: rotate(-45deg);
    -webkit-transform: rotate(-45deg);
    }

    i{
  border: solid black;
    border-width: 0 3px 3px 0;
  display: inline-block;
  padding: 3px;
}
#InProgress {
border-radius: 15px;
    border: 2px solid #73AD21;
    padding: 20px; 
    width:  auto;
    height: auto;    
    font-family:Tahoma;
} 

#NotYetStarted {
    border-radius: 15px;
    border: 2px solid #A4A0A0;
    padding: 20px; 
    width:  auto;
    height: auto;    
    font-family:Tahoma;
} 
#startNend {
    border-radius: 15px;
    background: #FF6347;
    align-content: center;
    padding: 20px; 
    color:white;
    width:  auto;
    height: auto;    
    font-family:Tahoma;
}	
#rcornersArrow {
    border-radius: 75px;    
    padding: 20px;  
} </style>
<script src = ""https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js""></script>
  </head>
<body>

<div ng-app="""" ng-init=""names=[{name:'No Process Found',tooltip:'Status:NotYetStarted',status:'NotYetStarted',img:'code'}]"">
<center> 
 <h2 style = ""font-family:Tahoma;""> Robotic Process Flow Diagram</h2>
</center>
<hr/>
<table><tr><td><h3>&nbsp;&nbsp;Robot Name : </h3> </td><td><h3 style = ""font-family:Tahoma;color:#b30000""> @RobotName</h3></td></tr></table>

<br/>   
 <center>
<div>
 <div style=""float: left;""><table width = 100%><tr><td align=center width = 50 height=50>
  <div class=""fa fa-eercast"" style=""font-size:36px""></div>
  </td></tr><tr><td id = ""startNend"" align=center valign = middle> START </td></tr></table> </div>
 <div style=""float: left;"">
 <table width = 100%><tr><td align=center width = 50 height=50> 
 </td></tr><tr><td id = ""rcornersArrow""><i class=""right""></i></td></tr></table>
 </div>
 </div>  
<div ng-repeat=""x in names"">
 <div style = ""float: left;""><table width=100%><tr><td align = center   width=50 height=50>
 
 <div ng-if=""x.img.indexOf('.') !== -1"">  
 <img src = ""{{ x.img }}"" width=45 height=45 />
      </div>
       <div ng-if= ""x.img.indexOf('.') == -1"" >
        <div class=""fa fa-{{ x.img }}""  width=50 height=50 style=""font-size:36px""> </div>
 </div>
   </td></tr><tr><td title = ""{{ x.tooltip }}""  id=""{{ x.status }}"" align=center valign = middle>{{ x.name }}</td></tr></table> </div>
 <div style = ""float: left;"">
 <table  width=100%><tr><td align = center  width=50 height=50>
 </td></tr><tr><td id = ""rcornersArrow""><i class=""right""></i></td></tr></table>
 </div>
 </div>
 </div> 
<div>
 <div style = ""float: left;""><table width=100%><tr><td align = center width=50 height=50>
  <div class=""fa fa-eercast"" style=""font-size:36px""></div>
  </td></tr><tr><td id = ""startNend"" align=center valign = middle> END </td></tr></table> </div>
 </div>
</center>
</body>
</html>
";
        }
    }
    public class JSonStage
    {
        public string name { get; set; }
        public string tooltip { get; set; }
        public string status { get; set; }
        public string img { get; set; }
    }
  
}
